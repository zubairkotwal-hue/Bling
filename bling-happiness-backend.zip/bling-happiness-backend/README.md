# Bling Happiness — admin login setup

Netlify Identity has been removed entirely. The admin password is now
checked on the SERVER by the backend functions, which is both simpler and
genuinely secure — the password never lives in the page code, and every
single request re-checks it.

## THE ONE THING YOU MUST DO

Set the admin password as an environment variable:

1. Netlify → Project configuration → Environment variables
2. Add a variable:
   - Key:   ADMIN_PASSWORD
   - Value: (the password you want)
3. Deploys → Trigger deploy

Until this variable is set, NOBODY can log in — the functions deny
everything when no password is configured. That's deliberate.

To change the password later, just edit this variable and redeploy. No
code changes, no files to touch.

## Files to update on GitHub

- public/index.html                    (replaced — login box, no widget)
- netlify/functions/_utils.js          (replaced — server-side password check)
- netlify/functions/admin-login.js     (NEW — checks the password)
- netlify/functions/stories.js         (updated)
- netlify/functions/replies.js         (updated)
- netlify/functions/products.js        (updated)
- netlify/functions/leads.js           (updated)

You can also delete netlify/functions/setup-db.js if it's still there —
the database tables are already created.

## Before taking real orders

In public/index.html, search for BANK_DETAILS and replace the placeholder
with the real banking details. Customers see that text on order
confirmations.
